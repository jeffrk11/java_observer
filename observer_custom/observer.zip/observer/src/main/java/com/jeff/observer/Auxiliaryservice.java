package com.jeff.observer;

public interface Auxiliaryservice {

    Object save(Object payload);

    void rollback();
}
